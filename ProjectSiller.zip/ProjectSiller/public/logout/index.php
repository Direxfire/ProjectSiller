<?php
session_start();
unset($_SESSION['ID']);
unset($_SESSION['Team_Number']);
session_destroy();
header('location: ../');
?>