<?php
require('../../inc/init.php');
if (!($user -> LoggedIn($db_connect))) {
	header('location: ../');
	die();
} 
if(isset($_GET['request'])) {
	$request = strip_tags(htmlentities($_GET['request']));
	switch($request) {
		case('1391'):
		require('1391.php');
		break;
		case('collab'):
		require('collab.php');
		break;
		case('pitscouting'):
		require('pit.php');
		break;
	}
} else {
	require('1391.php');
}