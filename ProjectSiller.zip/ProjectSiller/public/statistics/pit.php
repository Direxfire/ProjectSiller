<?php
if (__FILE__ == $_SERVER['SCRIPT_FILENAME']) {
  echo '<html>
  <head><title>WAF Triggered</title></head>
  <body bgcolor="white">
    <center><h1>Web Application Firewall Triggered: Access Denied</h1></center>
    <hr><center>Steel Mountain Networks</center>
  </body>
  </html>';
  die();
}
// Translate data through function
function binary($input) {
  if($input == 0) {
    echo 'No';
  } elseif($input == 1) {
    echo 'Yes';
  } else {
    echo 'N/A';
  }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>Project Siller</title>

  <?php if(isset($_GET['teams'])) { ?>
  <!-- Bootstrap -->
  <link rel="stylesheet" href="../../assets/css/please-wait.css">
  <link rel="stylesheet" href="../../assets/css/spinkit.css">
  <link href="../../assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="../../assets/css/index.css" rel="stylesheet">
  <link rel="stylesheet" href="../../assets/css/sweetalert2.min.css">

  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="../../assets/js/jquery.min.js"></script>
  <script src="../../assets/js/jquery.cookie.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="../../assets/js/bootstrap.min.js"></script>
  <script src="../../assets/js/sweetalert2.min.js"></script>
  <?php } else { ?>
  <!-- Bootstrap -->
  <link rel="stylesheet" href="../assets/css/please-wait.css">
  <link rel="stylesheet" href="../assets/css/spinkit.css">
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/css/index.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/sweetalert2.min.css">

  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="../assets/js/jquery.min.js"></script>
  <script src="../assets/js/jquery.cookie.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="../assets/js/bootstrap.min.js"></script>
  <script src="../assets/js/sweetalert2.min.js"></script>
  <?php } ?>
</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <?php if(isset($_GET['teams'])) { ?>
        <a class="navbar-brand" href="../../">Project Siller</a>
      </div>
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
          <?php if($user -> contribute($db_connect)) { ?>
          <li><a href="../../pit">Pit Scouting</a></li>
          <li><a href="../../">Match Scouting</a></li>
          <?php } ?>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Statistics <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="../1391">1391</a></li>
              <li><a href="../collaborative">Collaborative</a></li>
              <li class="active"><a href="/">Pit Scouting</a></li>
            </ul>
          </li>
          <?php if($user -> admin($db_connect)){ ?>
          <li><a href="../../overwatch/">Overwatch</a></li>
          <?php } ?>
        </ul>
      </div>
      <?php } else {?>
      <a class="navbar-brand" href="../">Project Siller</a>
    </div>
    <div id="navbar" class="collapse navbar-collapse">
      <ul class="nav navbar-nav navbar-right">
        <?php if($user -> contribute($db_connect)) { ?>
        <li><a href="../pit">Pit Scouting</a></li>
        <li><a href="../">Match Scouting</a></li>
        <?php } ?>
        <li class="dropdown">
          <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Statistics <span class="caret"></span></a>
          <ul class="dropdown-menu">
            <li><a href="1391">1391</a></li>
            <li><a href="collaborative">Collaborative</a></li>
            <li class="active"><a href="/">Pit Scouting</a></li>
          </ul>
        </li>
        <?php if($user -> admin($db_connect)){ ?>
        <li><a href="../overwatch/">Overwatch</a></li>
        <?php } ?>
      </ul>
    </div>
    <?php } ?>
  </div>
</nav>

<div class="col-md-8 col-md-offset-2">
  <div class="alert alert-info text-center" style="font-size: 17px;">Provided by Team 1391 &amp; Team 272</div>
  <h2 class="text-center underlined">Pit Scouting Data</h2>
  <br>
  <div class="panel panel-success">
    <div class="panel-heading"><h2 class="panel-title">Request Teams</h2></div>
    <div class="panel-body">
      <div class="col-md-12">
        <form method="POST">
          <p style="font-size: 17px;"><b>Put in team numbers separated by a space</b></p>
          <div class="col-md-12"> 
            <!-- New Data Validation -->
            <input class="form-control" type="text" name="teams" required autocomplete="off" placeholder="1391 1640 1712">
          </div>
          <div class="col-md-12">
            <br>
            <button class="btn btn-success btn-block" type="submit" name="request">Request</button>
          </div>
        </form>
      </div>
    </div>
  </div>
  <?php
  if(isset($_POST['request'])) {
    $teams = strip_tags(htmlentities($_POST['teams']));
    // Do not remove space from response, for URL encode
    header('Location: /statistics/pitscouting/'.urlencode($teams).'');
  }
  if(isset($_GET['teams'])) {
    $teams = strip_tags(htmlentities($_GET['teams']));
    // New data validation
    $teams = explode('+', $teams);
    $nodata = array();
    foreach($teams as $key => $data) {
      if(is_numeric($data)) {
       $ghost_check_init = $db_connect -> prepare("SELECT COUNT(*) FROM `pit` WHERE `Team_Number` = :request LIMIT 1");
       $ghost_check_init -> execute(array(':request' => $data));
       $ghost_check = $ghost_check_init -> fetchColumn(0);
       if($ghost_check > 0) {
        echo '<div class="panel panel-danger">
        <div class="panel-heading"><h2 class="panel-title">Team '.$data.'</h2></div><div class="panel-body">';
          // Basically retrieve all data and echo it out
        $god_retrieve_init = $db_connect -> prepare("SELECT * FROM `pit` WHERE `Team_Number` = :requested LIMIT 1");
        $god_retrieve_init -> execute(array(':requested' => $data));
        while($god_data = $god_retrieve_init -> fetch(PDO::FETCH_ASSOC)) {
          echo '<h4>Basic Info: </h4>';
          if($user -> admin($db_connect)) {
              // Protect scout identity, Admin only
            echo '<h5>Scout Name: '.ucfirst($god_data['Scout']).'</h5>';
          }
          echo '<h5>Volume: '.$god_data['Volume'].'</h5>';
          echo '<h5>Ball Storage Capacity: '.$god_data['Ball_Storage'].' Balls</h5>';
          echo '<h5>Own Rope: ';
          binary($god_data['Rope']);
          echo '</h5>';
          echo '<h5>Need Pilot: ';
          binary($god_data['Pilot']);
          echo '</h5>';
          echo '<h5>Vision Targeting System: ';
          binary($god_data['Vision']);
          echo '</h5>';
          echo '<h5>Gear Ground Collector: ';
          binary($god_data['Gear_Ground_Collector']);
          echo '</h5>';
          echo '<hr>';
          echo '<h4>Autonomous: </h4>';
          echo '<h5>Cross Baseline: ';
          binary($god_data['Auton_baseline']);
          echo '</h5>';
          echo '<h5>Fuel*: ';
          binary($god_data['Gear_Ground_Collector']);
          echo '</h5>';
          echo '<h5>Gear Placement Location: '.$god_data['Auton_Gear_Location'].'</h5>';
          echo '<h5>Hopper Activation: ';
          binary($god_data['Auton_Hopper']);
          echo '</h5>';
          if($god_data['Auton_Hopper'] == 1) {
            echo '<h5>Hopper Location*: '.$god_data['Auton_Hopper_Location'].'</h5>';
          }
          echo '<h5>Collect Fuel: ';
          binary($god_data['Auton_Fuel_Collect']);
          echo '</h5>';
          if($god_data['Auton_Fuel_Collect'] == 1) {
            echo '<h5>Shoot Collected Fuel*: '.$god_data['Auton_Hopper_Location'].'</h5>';
          }
          echo '<hr>';
          echo '<h4>Tele-Op: </h4>';
          echo '<h5>Fuel: '.$god_data['Teleop_Fuel'].'</h5>';
          echo '<h5>Fuel Location: '.$god_data['Teleop_Fuel_Location'].'</h5>';
          if($god_data['Teleop_Gear_Location'] == "Both") {
            echo '<h5>Gear Location: Ground &amp; Chute</h5>';
          } else {
            echo '<h5>Gear Location: '.$god_data['Teleop_Gear_Location'].'</h5>';
          }
          echo '<h5>Climb Rope: ';
          binary($god_data['Teleop_Rope']);
          echo '</h5>';
          if($god_data['Teleop_Rope'] == 1) {
            echo '<h5>Rope Location*: '.$god_data['Teleop_Rope_Location'].'</h5>';
          }
          echo '<hr>';
          echo '<h4>Drive Train: </h4>';
          echo '<h5>Type: '.$god_data['Drive_Type'].'</h5>';
          echo '<h5>Number of Wheels: '.$god_data['Drive_Wheel'].' Wheels</h5>';
          echo '<h5>Number of Drive Motors: '.$god_data['Drive_Motor_Number'].' Motors</h5>';
          echo '<h5>Drive Motor Type: '.ucfirst($god_data['Drive_Motor']).'</h5>';
          echo '<h5>Speed: '.$god_data['Drive_Speed'].' Feet Per Second</h5>';
          echo '<hr>';
          echo '<h4>Notes: </h4>';
          if(empty($god_data['Notes']) OR $god_data['Notes'] === NULL OR $god_data['Notes'] == " ") {
            echo '<div class="panel panel-default"><div class="panel-body"><span class="text-danger"><strong>No Notes Available</strong></span></div></div>';
          } else {
            echo '<div class="panel panel-default"><div class="panel-body">'.ucfirst($god_data['Notes']).'</div></div>';
          }
          echo '<br><p style="font-size: 12px;">*Not accurate due to lack of options at the time. "Low" could be none.</p>';
          if($god_data['Auton_Hopper'] == 1) {
            echo '<p style="font-size: 12px;">*Only shows up if "Hopper Activation" is true.</p>';
          }
          if($god_data['Auton_Fuel_Collect'] == 1) {
            echo '<p style="font-size: 12px;">*Only shows up if "Fuel Collection" is true.</p>';
          }
          if($god_data['Teleop_Rope'] == 1) {
            echo '<p style="font-size: 12px;">*Only shows up if "Rope Location" is true.</p>';
          }
          echo '</div></div>';
        }
      } else {
        echo '<div class="alert alert-danger text-center" style="font-size: 20px;"><strong>Fatal Error: No data for Team '.$data.'</strong></div>';
      }
    } else {
      echo '<div class="alert alert-danger text-center" style="font-size: 20px;"><strong>Fatal Error: Query not allowed</strong></div>';
    }
  }
}
?>
</div>

<?php if(isset($_GET['teams'])) { ?>
<script type="text/javascript" src="../../assets/js/please-wait.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    if($.cookie('loading') == undefined || $.cookie('loading') == null) {
      window.loading_screen = window.pleaseWait({
        logo: "../../assets/images/logo.svg",
        backgroundColor: '#AC1B1E',
        loadingHtml: "<p class='loading-message'>Project Siller<br>A online scouting platform for FIRST Robotics</p><div class='sk-spinner sk-spinner-three-bounce'><div class='sk-bounce1'></div><div class='sk-bounce2'></div><div class='sk-bounce3'></div></div>"
      });
      setTimeout(function() { window.loading_screen.finish();}, 3000);
      var date = new Date();
      date.setTime(date.getTime() + (5 * 60 * 1000));
      $.cookie("loading", "true", { expires: date });
    }
  });
</script>
<?php } else { ?>
<script type="text/javascript" src="../assets/js/please-wait.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    if($.cookie('loading') == undefined || $.cookie('loading') == null) {
      window.loading_screen = window.pleaseWait({
        logo: "../assets/images/logo.svg",
        backgroundColor: '#AC1B1E',
        loadingHtml: "<p class='loading-message'>Project Siller<br>A online scouting platform for FIRST Robotics</p><div class='sk-spinner sk-spinner-three-bounce'><div class='sk-bounce1'></div><div class='sk-bounce2'></div><div class='sk-bounce3'></div></div>"
      });
      setTimeout(function() { window.loading_screen.finish();}, 3000);
      var date = new Date();
      date.setTime(date.getTime() + (5 * 60 * 1000));
      $.cookie("loading", "true", { expires: date });
    }
  });
</script>
<?php } ?>
</body>
</html>