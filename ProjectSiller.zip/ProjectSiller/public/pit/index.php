<?php
ob_start();
require('../../inc/init.php');
if (!($user -> LoggedIn($db_connect))) {
  header('location: ../');
  die();
} 
if(!($user -> contribute($db_connect))) {
  header('location: ../');
  die();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>Project Siller</title>

  <!-- Bootstrap -->
  <link rel="stylesheet" href="../assets/css/please-wait.css">
  <link rel="stylesheet" href="../assets/css/spinkit.css">
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/css/index.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/sweetalert2.min.css" />
  <link rel="stylesheet" href="../assets/css/jquery-ui.min.css">
  <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
  <script src="../assets/js/jquery.min.js"></script>
  <script src="../assets/js/jquery.cookie.js"></script>
  <!-- Include all compiled plugins (below), or include individual files as needed -->
  <script src="../assets/js/bootstrap.min.js"></script>
  <script src="../assets/js/sweetalert2.min.js"></script>
  <script src="../assets/js/jquery-ui.min.js"></script>
</head>
<body>
  <nav class="navbar navbar-inverse navbar-fixed-top">
    <div class="container-fluid">
      <div class="navbar-header">
        <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
          <span class="sr-only">Toggle navigation</span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
          <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="index.php">Project Siller</a>
      </div>
      <div id="navbar" class="collapse navbar-collapse">
        <ul class="nav navbar-nav navbar-right">
          <li class="active"><a href="/">Pit Scouting</a></li>
          <li><a href="../match">Match Scouting</a></li>
          <li class="dropdown">
            <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">Statistics <span class="caret"></span></a>
            <ul class="dropdown-menu">
              <li><a href="../statistics/1391">1391</a></li>
              <li><a href="../statistics/collaborative">Collaborative</a></li>
              <li><a href="../statistics/pitscouting">Pit Scouting</a></li>
            </ul>
          </li>
          <?php if($user -> admin($db_connect)){ ?>
          <li><a href="../overwatch/">Overwatch</a></li>
          <?php } ?>
        </ul>
      </div>
    </div>
  </nav>

  <?php
  if(isset($_POST['submit'])) {
    $ghostcheck = $db_connect -> prepare("SELECT COUNT(*) FROM `pit` WHERE `Team_Number` = :teamgiven LIMIT 1");
    $ghostcheck -> execute(array(':teamgiven' => $_POST['teamnumber']));
    $ghostresult = $ghostcheck -> fetchColumn(0);
    if($ghostresult == 0) {
      $dontcrash = $db_connect -> prepare("INSERT INTO `pit` VALUES(NULL, :scout, :team_number, :volume, :ball_storage, :rope, :pilot, :vision, :gear_ground_collector, :auton_baseline, :auton_fuel, :auton_gear, :auton_gear_location, :auton_hopper, :auton_hopper_location, :auton_fuel_collect, :auton_fuel_shoot, :teleop_fuel, :teleop_fuel_location, :teleop_gear_location, :teleop_rope, :teleop_rope_location, :drive_type, :drive_wheel, :drive_motor, :drive_speed, :drive_motor_number, :notes)"  );
      $dontcrash -> execute(array(':scout' => $_POST['scout'], ':team_number' => $_POST['teamnumber'], ':volume' => $_POST['volume'], ':ball_storage' => $_POST['ballstorage'], ':rope' => $_POST['rope'], ':pilot' => $_POST['pilot'], ':vision' => $_POST['vision'], ':gear_ground_collector' => $_POST['groundgear'], ':auton_baseline' => $_POST['baseline'], ':auton_fuel' => $_POST['fuel_auton'], ':auton_gear' => $_POST['gear_auton'], ':auton_gear_location' => $_POST['autongear_location'], ':auton_hopper' => $_POST['autonhopper'], ':auton_hopper_location' => $_POST['autonhopper_location'], ':auton_fuel_collect' => $_POST['auton_collectfuel'], ':auton_fuel_shoot' => $_POST['auton_shootfuel'], ':teleop_fuel' => $_POST['teleop_fuel'], ':teleop_fuel_location' => $_POST['teleop_fuellocation'], ':teleop_gear_location' => $_POST['teleop_gearlocation'], ':teleop_rope' => $_POST['teleop_climbrope'], ':teleop_rope_location' => $_POST['teleop_climbrope_location'], ':drive_type' => $_POST['drivetype'], ':drive_wheel' => $_POST['drivewheel'], ':drive_motor' => $_POST['drivemotor'], ':drive_speed' => $_POST['drivespeed'], ':drive_motor_number' => $_POST['drivemotor_number'], ':notes' => $_POST['notes']));
      echo "<script>
      $(document).ready(function() {
        swal(
        'Success!',
        'Data has been saved!',
        'success'
        );});</script>";
      } else {
        echo "<script>
        $(document).ready(function() {
          swal(
          'Error!',
          'Data already exists!',
          'error'
          );});</script>";
        }
      }
      ?>

      <div class="container">
        <div class="panel panel-info">
          <div class="panel-heading"> <h2 class="panel-title">Pitscouting</div>
          <div class="panel-body">
            <form method="POST">
              <div class="col-md-12">
                <div class="form-group col-md-6">
                  <label for="scout">Scout Name</label>
                  <input class="form-control" name="scout" id="scout" type="text" autocomplete="off" autofocus required>
                </div>
                <div class="form-group col-md-6">
                  <label for="teamnumber">Team Number</label>
                  <input class="form-control" name="teamnumber" id="teamnumber" type="number" autocomplete="off" required>
                </div>
              </div>
              <div class="col-md-12">
                <h4 class="text-center underlined">General Information</h4>
                <div class="form-group col-md-4">
                  <label for="volume">Volume</label>
                  <div class="radio" data-toggle="buttons">
                    <label class="radio-inline btn btn-success sharespace"><input class="sr-only" type="radio" name="volume" value="Tall" required>Tall</label>
                    <label class="radio-inline btn btn-danger sharespace"><input class="sr-only" type="radio" name="volume" value="Low" required>Low</label>
                  </div>
                </div>
                <div class="form-group col-md-4">
                  <label for="ballstorage">Ball Storage Size</label>
                  <input class="form-control" name="ballstorage" type="number" autocomplete="off" required>
                </div>
                <div class="form-group col-md-4">
                 <label for="rope">Own Rope</label>
                 <div class="radio" data-toggle="buttons">
                  <label class="radio-inline btn btn-success sharespace"><input class="sr-only" type="radio" name="rope" value="1" required>Yes</label>
                  <label class="radio-inline btn btn-danger sharespace"><input class="sr-only" type="radio" name="rope" value="0" required>No</label>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="form-group col-md-4">
                <label for="pilot">Need Pilot</label>
                <div class="radio" data-toggle="buttons">
                  <label class="radio-inline btn btn-success sharespace"><input class="sr-only" type="radio" name="pilot" value="1" required>Yes</label>
                  <label class="radio-inline btn btn-danger sharespace"><input class="sr-only" type="radio" name="pilot" value="0" required>No</label>
                </div>
              </div>
              <div class="form-group col-md-4">
                <label for="vision">Vision Targeting</label>
                <div class="radio" data-toggle="buttons">
                  <label class="radio-inline btn btn-success sharespace"><input class="sr-only" type="radio" name="vision" value="1" required>Yes</label>
                  <label class="radio-inline btn btn-danger sharespace"><input class="sr-only" type="radio" name="vision" value="0" required>No</label>
                </div>
              </div>
              <div class="form-group col-md-4">
               <label for="groundgear">Gear Ground Collector</label>
               <div class="radio" data-toggle="buttons">
                <label class="radio-inline btn btn-success sharespace"><input class="sr-only" type="radio" name="groundgear" value="1" required>Yes</label>
                <label class="radio-inline btn btn-danger sharespace"><input class="sr-only" type="radio" name="groundgear" value="0" required>No</label>
              </div>
            </div>
          </div>
          <div class="col-md-12">
            <h4 class="text-center underlined">Autonomous</h4>
            <div class="form-group col-md-3">
              <label for="baseline">Cross Baseline</label>
              <div class="radio" data-toggle="buttons">
                <label class="radio-inline btn btn-success sharespace"><input class="sr-only" type="radio" name="baseline" value="1" required>Yes</label>
                <label class="radio-inline btn btn-danger sharespace"><input class="sr-only" type="radio" name="baseline" value="0" required>No</label>
              </div>
            </div>
            <div class="form-group col-md-3">
              <label for="fuel_auton">Fuel</label>
              <div class="radio" data-toggle="buttons">
                <label class="radio-inline btn btn-success sharespace"><input class="sr-only" type="radio" name="fuel_auton" value="high" required>High</label>
                <label class="radio-inline btn btn-danger sharespace"><input class="sr-only" type="radio" name="fuel_auton" value="low" required>Low</label>
              </div>
            </div>
            <div class="form-group col-md-2">
              <label for="gear_auton">Gear Placement</label>
              <div class="radio" data-toggle="buttons">
                <label class="radio-inline btn btn-success sharespace"><input class="sr-only" type="radio" name="gear_auton" value="1" required>Yes</label>
                <label class="radio-inline btn btn-danger sharespace"><input class="sr-only" type="radio" name="gear_auton" value="0" required>No</label>
              </div>
            </div>
            <div class="form-group col-md-4">
              <label for="autongear_location">Gear Placement Location</label>
              <div class="radio" data-toggle="buttons">
                <label class="radio-inline btn btn-danger"><input class="sr-only" type="radio" name="autongear_location" value="Any" required>Any</label>
                <label class="radio-inline btn btn-success"><input class="sr-only" type="radio" name="autongear_location" value="G1" required>G1</label>
                <label class="radio-inline btn btn-warning"><input class="sr-only" type="radio" name="autongear_location" value="G2" required>G2</label>
                <label class="radio-inline btn btn-info"><input class="sr-only" type="radio" name="autongear_location" value="G3" required>G3</label>
                <label class="radio-inline btn btn-primary"><input class="sr-only" type="radio" name="autongear_location" value="None" required>None</label>
              </div>
            </div>
          </div>
          <div class="col-md-12">
           <div class="form-group col-md-3">
            <label for="autonhopper">Active Hopper</label>
            <div class="radio" data-toggle="buttons">
              <label class="radio-inline btn btn-success sharespace"><input class="sr-only" type="radio" name="autonhopper" value="1" required>Yes</label>
              <label class="radio-inline btn btn-danger sharespace"><input class="sr-only" type="radio" name="autonhopper" value="0" required>No</label>
            </div>
          </div>
          <div class="form-group col-md-3">
            <label for="autonhopper_location">Active Hopper Location</label>
            <select class="form-control" name="autonhopper_location" required>
              <option value="Any" selected>Any</option>
              <option value="H1">H1</option>
              <option value="H2">H2</option>
              <option value="H3">H3</option>
              <option value="H4">H4</option>
              <option value="H5">H5</option>
              <option value="None">None</option>
            </select>
          </div>
          <div class="form-group col-md-3">
            <label for="auton_collectfuel">Collect Fuel</label>
            <div class="radio" data-toggle="buttons">
              <label class="radio-inline btn btn-success sharespace"><input class="sr-only" type="radio" name="auton_collectfuel" value="1" required>Yes</label>
              <label class="radio-inline btn btn-danger sharespace"><input class="sr-only" type="radio" name="auton_collectfuel" value="0" required>No</label>
            </div>
          </div>
          <div class="form-group col-md-3">
            <label for="auton_shootfuel">Shoot Collected Fuel</label>
            <div class="radio" data-toggle="buttons">
              <label class="radio-inline btn btn-success sharespace"><input class="sr-only" type="radio" name="auton_shootfuel" value="1" required>Yes</label>
              <label class="radio-inline btn btn-danger sharespace"><input class="sr-only" type="radio" name="auton_shootfuel" value="0" required>No</label>
            </div>
          </div>
        </div>
        <div class="col-md-12">
          <h4 class="text-center underlined">Tele-Op</h4>
          <div class="form-group col-md-3">
            <label for="teleop_fuel">Fuel</label>
            <div class="radio" data-toggle="buttons">
              <label class="radio-inline btn btn-success"><input class="sr-only" type="radio" name="teleop_fuel" value="N/A" required>N/A</label>
              <label class="radio-inline btn btn-primary"><input class="sr-only" type="radio" name="teleop_fuel" value="High" required>High</label>
              <label class="radio-inline btn btn-danger"><input class="sr-only" type="radio" name="teleop_fuel" value="Low" required>Low</label>
            </div>
          </div>
          <div class="form-group col-md-5">
            <label for="teleop_fuellocation">Fuel Location</label>
            <div class="radio" data-toggle="buttons">
              <label class="radio-inline btn btn-danger"><input class="sr-only" type="radio" name="teleop_fuellocation" value="N/A" required>N/A</label>
              <label class="radio-inline btn btn-success"><input class="sr-only" type="radio" name="teleop_fuellocation" value="Ground" required>Ground</label>
              <label class="radio-inline btn btn-warning"><input class="sr-only" type="radio" name="teleop_fuellocation" value="Hopper" required>Hopper</label>
              <label class="radio-inline btn btn-primary"><input class="sr-only" type="radio" name="teleop_fuellocation" value="Both" required>Both</label>
            </div>
          </div>
          <div class="form-group col-md-4">
            <label for="teleop_gearlocation">Gear Location</label>
            <div class="radio" data-toggle="buttons">
              <label class="radio-inline btn btn-danger"><input class="sr-only" type="radio" name="teleop_gearlocation" value="N/A" required>N/A</label>
              <label class="radio-inline btn btn-success"><input class="sr-only" type="radio" name="teleop_gearlocation" value="Ground" required>Ground</label>
              <label class="radio-inline btn btn-warning"><input class="sr-only" type="radio" name="teleop_gearlocation" value="Chute" required>Chute</label>
              <label class="radio-inline btn btn-primary"><input class="sr-only" type="radio" name="teleop_gearlocation" value="Both" required>Both</label>
            </div>
          </div>
        </div>
        <div class="col-md-12">
          <div class="form-group col-md-6">
            <label for="teleop_climbrope">Climb Rope</label>
            <div class="radio" data-toggle="buttons">
              <label class="radio-inline btn btn-success sharespace"><input class="sr-only" type="radio" name="teleop_climbrope" value="1" required>Yes</label>
              <label class="radio-inline btn btn-danger sharespace"><input class="sr-only" type="radio" name="teleop_climbrope" value="0" required>No</label>
            </div>
          </div>
          <div class="form-group col-md-6">
            <label for="teleop_climbrope_location">Rope Location</label>
            <div class="radio" data-toggle="buttons">
              <label class="radio-inline btn btn-success"><input class="sr-only" type="radio" name="teleop_climbrope_location" value="Any" required>Any</label>
              <label class="radio-inline btn btn-danger"><input class="sr-only" type="radio" name="teleop_climbrope_location" value="Left" required>Left</label>
              <label class="radio-inline btn btn-warning"><input class="sr-only" type="radio" name="teleop_climbrope_location" value="Center" required>Center</label>
              <label class="radio-inline btn btn-primary"><input class="sr-only" type="radio" name="teleop_climbrope_location" value="Right" required>Right</label>
              <label class="radio-inline btn btn-info"><input class="sr-only" type="radio" name="teleop_climbrope_location" value="N/A" required>N/A</label>
            </div>
          </div>
        </div>
        <div class="col-md-12">
          <h4 class="text-center underlined">Drive Train</h4>
          <div class="form-group col-md-5">
            <label for="drivetype">Type</label>
            <div class="radio" data-toggle="buttons">
              <label class="radio-inline btn btn-success"><input class="sr-only" type="radio" name="drivetype" value="Tank" required>Tank</label>
              <label class="radio-inline btn btn-danger"><input class="sr-only" type="radio" name="drivetype" value="Mecanum" required>Mecanum</label>
              <label class="radio-inline btn btn-warning"><input class="sr-only" type="radio" name="drivetype" value="Swerve" required>Swerve</label>
              <label class="radio-inline btn btn-primary"><input class="sr-only" type="radio" name="drivetype" value="Other" required>Other</label>
            </div>
          </div>
          <div class="form-group col-md-3">
            <label for="drivewheel">Number of Wheels</label>
            <input class="form-control" name="drivewheel" type="number" autocomplete="off" required>
          </div>
          <div class="form-group col-md-4">
            <label for="drivemotor_number">Number of Drive Motors</label>
            <input class="form-control" name="drivemotor_number" type="number" autocomplete="off" required>
          </div>
        </div>
        <div class="form-group col-md-12">
          <div class="form-group col-md-6">
            <label for="drivemotor">Drive Motor Type</label>
            <input class="form-control" name="drivemotor" type="text" autocomplete="off" required>
          </div>
          <div class="col-md-6">
            <label for="drivespeed">Speed (Feet Per Second)</label>
            <input class="form-control" name="drivespeed" type="number" autocomplete="off" required>
          </div>
        </div>
        <div class="col-md-12">
          <h4 class="text-center underlined">Notes</h4>
          <div class="form-group col-md-12">
            <textarea class="form-control" maxlength="225" rows="5" name="notes" autocomplete="off" required placeholder="Realistic? Oddities? Speciality?"></textarea>
          </div>
        </div>
        <div class="col-md-12" style="margin-top: 20px;">
          <button class="btn btn-success btn-block" tpye="submit" name="submit">Save</button>
        </div>
      </form>
    </div>
  </div>
</div>
<script src="../assets/js/mobile.js"></script>
<script type="text/javascript" src="../assets/js/please-wait.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    if($.cookie('loading') == undefined || $.cookie('loading') == null) {
      window.loading_screen = window.pleaseWait({
        logo: "../assets/images/logo.svg",
        backgroundColor: '#AC1B1E',
        loadingHtml: "<p class='loading-message'>Project Siller<br>A online scouting platform for FIRST Robotics</p><div class='sk-spinner sk-spinner-three-bounce'><div class='sk-bounce1'></div><div class='sk-bounce2'></div><div class='sk-bounce3'></div></div>"
      });
      setTimeout(function() { window.loading_screen.finish();}, 3000);
      var date = new Date();
      date.setTime(date.getTime() + (5 * 60 * 1000));
      $.cookie("loading", "true", { expires: date });
    }
  });
</script>
</body>
</html>
