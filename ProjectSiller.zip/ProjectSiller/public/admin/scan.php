<?php
require("../../inc/init.php");
if(!($user->admin($db_connect))) {
  header('Location: ../');
  die();
}
?>
<html>
<head>
  <title>QRCODE</title>
  <style type="text/css">
  </style>
  <script type="text/javascript" src="llqrcode.js"></script>
  <script type="text/javascript" src="https://apis.google.com/js/plusone.js"></script>
  <script type="text/javascript" src="webqr.js"></script>
</head>
<body onload="load()">
  <div id="mainbody">
    <table class="tsel" border="0" width="100%">
      <tr>
        <td valign="top" align="center" width="50%">
          <table class="tsel" border="0">
            <tr>
              <td><img class="selector" id="qrimg" src="cam.png" onclick="setimg()" align="right"/></td></tr>
              <tr><td colspan="2" align="center">
                <div id="outdiv">
                </div></td></tr>
              </table>
            </td>
          </tr>
          <tr><td colspan="3" align="center">
            <img src="down.png"/>
          </td></tr>
          <tr><td colspan="3" align="center">
            <div id="result"></div>
          </td></tr>
        </table>
        <canvas id="qr-canvas" width="800" height="600"></canvas>
        <script type="text/javascript">load();</script>
      </body>
      </html>