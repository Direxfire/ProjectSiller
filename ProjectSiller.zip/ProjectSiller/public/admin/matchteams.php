<?php
require("../../inc/init.php");
if(!($user->admin($db_connect))) {
	header('Location: ../');
	die();
}
for($k = 1; $k <= 120; $k++) {
	$curl = curl_init();
	curl_setopt_array($curl, array(
		CURLOPT_URL => "https://www.thebluealliance.com/api/v3/match/2018tes_qm".$k."",
		CURLOPT_RETURNTRANSFER => true,
		CURLOPT_MAXREDIRS => 10,
		CURLOPT_TIMEOUT => 30,
		CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
		CURLOPT_CUSTOMREQUEST => "GET",
		CURLOPT_SSL_VERIFYHOST => 0,
		CURLOPT_SSL_VERIFYPEER => 0,
		CURLOPT_HTTPHEADER => array(
			"cache-control: no-cache",
			"content-type: multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
			"postman-token: 352cf268-6b33-dc81-b74b-927b93c865cb",
			"X-TBA-Auth-Key: 2EseK4K6vDhf5Lz9H7C6sNaxYM8cOgXLZNhViV9sjFVewlgduTT58jfAKPd7vUou"
			)
		));


	$result = json_decode(curl_exec($curl), true);
	curl_close($curl);
	foreach($result as $key => $data) {
		$blue = array();
		for($i = 0; $i < count($data['blue']['teams']); $i++) {
			if($data['blue']['teams'][$i] == "q" OR $data['blue']['teams'][$i] == "2") {
				continue;
			}
			$data['blue']['teams'][$i] = str_replace("frc", "", $data['blue']['teams'][$i]);
			array_push($blue, $data['blue']['teams'][$i]);
		}
		$red = array();
		for($i = 0; $i < count($data['red']['teams']); $i++) {
			if($data['red']['teams'][$i] == "q" OR $data['red']['teams'][$i] == "2") {
				continue;
			}
			$data['red']['teams'][$i] = str_replace("frc", "", $data['red']['teams'][$i]);
			array_push($red, $data['red']['teams'][$i]);
		}
		$insert = $db_connect -> prepare("INSERT INTO `match_master` VALUES(NULL, :matchnumber, :blue1, :blue2, :blue3, :red1, :red2, :red3)");
		$insert -> execute(array(':matchnumber' => $k, ':blue1' => $blue[0], ':blue2' => $blue[1], ':blue3' => $blue[2], ':red1' => $red[0], ':red2' => $red[1], ':red3' => $red[2]));
		echo "Match ".$k." done importing! <br>";
	}
}
