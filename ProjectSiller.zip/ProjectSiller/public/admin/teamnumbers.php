<?php
require("../../inc/init.php");
if(!($user->admin($db_connect))) {
	header('Location: ../');
	die();
}
$curl = curl_init();

curl_setopt_array($curl, array(
	CURLOPT_URL => "https://www.thebluealliance.com/api/v2/event/2017tes/teams",
	CURLOPT_RETURNTRANSFER => true,
	CURLOPT_MAXREDIRS => 10,
	CURLOPT_TIMEOUT => 30,
	CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
	CURLOPT_CUSTOMREQUEST => "GET",
	CURLOPT_SSL_VERIFYHOST => 0,
	CURLOPT_SSL_VERIFYPEER => 0,
	CURLOPT_HTTPHEADER => array(
		"cache-control: no-cache",
		"content-type: multipart/form-data; boundary=----WebKitFormBoundary7MA4YWxkTrZu0gW",
		"postman-token: 352cf268-6b33-dc81-b74b-927b93c865cb",
		"x-tba-app-id: 1391:project-siller:v01"
		)
	));


$result = json_decode(curl_exec($curl), true);
curl_close($curl);
$teams = array();
foreach($result as $key => $data) {
	array_push($teams, $data['team_number']);
}
function cmp($a, $b) {
	if ($a == $b) {
		return 0;
	}
	return ($a < $b) ? -1 : 1;
}
usort($teams, 'cmp');
foreach($teams as $key => $data) {
	echo '"'.$data.'",<br>';
}
?>