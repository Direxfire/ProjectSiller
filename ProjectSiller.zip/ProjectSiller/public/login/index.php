<?php
ob_start();
require('../../inc/init.php');
if ($user -> LoggedIn($db_connect))
{
  header('location: ../match');
  die();
} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
  <title>Project Siller</title>

  <!-- Bootstrap -->
  <link rel="stylesheet" href="../assets/css/please-wait.css">
  <link rel="stylesheet" href="../assets/css/spinkit.css">
  <link href="../assets/css/bootstrap.min.css" rel="stylesheet">
  <link href="../assets/css/login.css" rel="stylesheet">
  <link rel="stylesheet" href="../assets/css/sweetalert2.min.css" />
</head>
<body>
 <div class="site-wrapper">
  <div class="site-wrapper-inner">
    <div class="cover-container">
      <div class="inner cover">
       <form class="form-signin" method="post">
        <h2 class="form-signin-heading">Please sign in</h2>
        <label for="teamnumber" class="sr-only">Team Number</label>
        <input type="number" name="teamnumber" class="form-control" placeholder="Team Number" required autofocus>
        <label for="password" class="sr-only">Password</label>
        <input type="password" name="password" class="form-control" placeholder="Password" required>
        <button class="btn btn-lg btn-primary btn-block" type="submit" name="login">Sign in</button>
      </form>
    </div>
  </div>
</div>
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="../assets/js/jquery.min.js"></script>
<script src="../assets/js/jquery.cookie.js"></script>
<!-- Include all compiled plugins (below), or include individual files as needed -->
<script src="../assets/js/bootstrap.min.js"></script>
<script src="../assets/js/sweetalert2.min.js"></script>
<script type="text/javascript" src="../assets/js/please-wait.min.js"></script>
<script type="text/javascript">
  $(document).ready(function() {
    if($.cookie('loading') == undefined || $.cookie('loading') == null) {
      window.loading_screen = window.pleaseWait({
        logo: "../assets/images/logo.svg",
        backgroundColor: '#AC1B1E',
        loadingHtml: "<p class='loading-message'>Project Siller<br>A online scouting platform for FIRST Robotics</p><div class='sk-spinner sk-spinner-three-bounce'><div class='sk-bounce1'></div><div class='sk-bounce2'></div><div class='sk-bounce3'></div></div>"
      });
      setTimeout(function() { window.loading_screen.finish();}, 3000);
      var date = new Date();
      date.setTime(date.getTime() + (5 * 60 * 1000));
      $.cookie("loading", "true", { expires: date });
    }
  });
</script>
<?php
if(isset($_POST['login'])) {
  $teamnumber = strip_tags(htmlentities($_POST['teamnumber']));
  $password = strip_tags(htmlentities($_POST['password']));
  $ghost_check_init = $db_connect -> prepare("SELECT COUNT(*) FROM `login` WHERE `Team_Number` = :input LIMIT 1");
  $ghost_check_init -> execute(array(':input' => $teamnumber));
  $ghost_check = $ghost_check_init -> fetchColumn(0);
  echo $ghost_check;
  if($ghost_check == 1) {
    $password_check = $db_connect -> prepare("SELECT `Hash` FROM `login` WHERE `Team_Number` = :input LIMIT 1");
    $password_check -> execute(array(':input' => $teamnumber));
    $password_db = $password_check -> fetchColumn(0);
    $check = password_verify($password, $password_db);
    if($check == 1) {
      $user_info_init = $db_connect -> prepare("SELECT * FROM `login` WHERE `Team_Number` = :input LIMIT 1");
      $user_info_init -> execute(array(':input' => $teamnumber));
      $user_info = $user_info_init -> fetch(PDO::FETCH_ASSOC);
      $_SESSION['ID'] = $user_info['ID'];
      $_SESSION['Team_Number'] = $user_info['Team_Number'];
      echo "<script>
      $(document).ready(function() {
        swal(
        'Login Success!',
        'Redirecting you to the dashboard...',
        'success'
        );
      });
    </script>";
    header('refresh:3;url=../statistics');
  } else {
    echo "<script>
    $(document).ready(function() {
      swal(
      'Login Error!',
      'Incorrect password.',
      'error'
      );
    });
  </script>";
}
} else {
  echo "<script>
  $(document).ready(function() {
    swal(
    'Login Error!',
    'This team is not registered.',
    'error'
    );
  });
</script>";
}
}
?>
</body>
</html>
