<?php
if (empty($_SERVER['HTTP_X_REQUESTED_WITH']) && !strtolower($_SERVER['HTTP_X_REQUESTED_WITH']) == 'xmlhttprequest') {
	echo "Error: Access Denied";
	die();
}
require('../../inc/db.php');
session_start();
if(isset($_POST['matchnumber_request']) && isset($_SESSION['position'])) {
	$new_position = str_replace(' ', '', $_SESSION['position']);
	$new_position = ucfirst($new_position);
	$sql = "SELECT ".$new_position." FROM `matches_master` WHERE `Match_Number` = ".$_POST['matchnumber_request']." LIMIT 1";
	$getteam_init = $db_connect -> prepare($sql);
	$getteam_init -> execute();
	$getteam_result = $getteam_init -> fetchColumn(0);
	echo $getteam_result;
}
?>